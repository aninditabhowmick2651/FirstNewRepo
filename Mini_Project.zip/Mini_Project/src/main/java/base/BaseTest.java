package base;

import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import freemarker.log.Logger;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageEvents.HomePageEvents;
import pageObjects.HomePageElements;
import pageObjects.LoginPageElements;
import utils.Constants;
import utils.fetchWebElement;

public class BaseTest {
	public static WebDriver driver;
	ExtentSparkReporter spark=new ExtentSparkReporter("extent.html");
	ExtentReports extent=new ExtentReports();
	public ExtentTest  logger;




	@BeforeTest
	public void beforeTest()
	{
		extent.attachReporter(spark);
	}
	@BeforeMethod
	@Parameters("browser")
	public void beforeMethod(String browserName, Method MethodName)
	{
		logger=extent.createTest(MethodName.getName());
		setupDriver(browserName);
		driver.manage().window().maximize();
		
		driver.get(Constants.url);
		//fetchWebElement fEle= new fetchWebElement();
		//HomePageEvents homeEle=new HomePageEvents();
		//Assert.assertTrue(fEle.getElement("XPATH", HomePageElements.SigninButton).isDisplayed(), "Login Button is present");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	@AfterMethod
	public void afterMethod(ITestResult result )
	{
		if(result.getStatus()== ITestResult.FAILURE)
		{
			logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+ "Test is failed", ExtentColor.RED));
			logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + "Failed because of", ExtentColor.RED));

		}
		else if(result.getStatus()==ITestResult.SKIP)
			logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + "Testcase is skipped", ExtentColor.ORANGE));
		else
			logger.log(Status.PASS, MarkupHelper.createLabel(result.getName() + "Testcase is passed", ExtentColor.GREEN));


	}

	public void setupDriver(String str)
	{
		if(str.equalsIgnoreCase("Chrome"))
		{
			
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();

		}
		else if(str.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();

		}
		
		else if(str.equalsIgnoreCase("Headless"))
		{
			ChromeOptions opt=new ChromeOptions();
			opt.addArguments("--headless=new");
			WebDriverManager.firefoxdriver().setup();
			driver=new ChromeDriver(opt);

		}
		else
		{
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}

	}

	@AfterTest
	public void afterTest()
	{
		//remove old data in report and create new report
		extent.flush();
		driver.quit();
	}



}

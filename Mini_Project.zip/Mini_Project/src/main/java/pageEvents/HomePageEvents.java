package pageEvents;

import base.BaseTest;
import pageObjects.HomePageElements;

import utils.fetchWebElement;

public class HomePageEvents {
	fetchWebElement fEle=new fetchWebElement();
	public void ClickSignInButton()
	{
		
		fEle.getElement("XPATH", HomePageElements.SigninButton).click();
		
	}
}

package utils;

public interface Constants {
	String url="https://freecrm.com/";

}

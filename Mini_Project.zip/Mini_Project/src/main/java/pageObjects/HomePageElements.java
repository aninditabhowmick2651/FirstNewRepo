package pageObjects;

public interface HomePageElements {
	
	String SigninButton="//*[text()='Log In']";
}

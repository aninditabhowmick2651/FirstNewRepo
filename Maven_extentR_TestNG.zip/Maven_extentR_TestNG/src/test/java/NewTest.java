import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class NewTest {
	ExtentReports extent=new ExtentReports();
	  ExtentSparkReporter spark=new ExtentSparkReporter("extent.html");
  @Test
  public void f1() {
	  ExtentTest test=extent.createTest("Launching browser");
	  test.log(Status.PASS, "browser lauched!!");
	  test.pass("user launched broeser!!");
  }
  @Test
  public void f2() {
	  ExtentTest test=extent.createTest("Loging browser");
	  test.info("on login page");
	  test.warning("reset password is displayed");
  }
  @Test
  public void f3() {
	  ExtentTest test=extent.createTest("Dashboard").assignAuthor("Anindita").assignCategory("Sanity").assignDevice("Chrome");  
			  test.skip("it's a skip warning!");
  }
  @Test
  public void f4() {
	  ExtentTest test=extent.createTest("Verify page");
  }
  @Test
  public void f5() {
	  ExtentTest test=extent.createTest("Logout");
  }
  
  @BeforeTest
  public void beforeTest() {
	  
	  extent.attachReporter(spark);
  }
  

  @AfterTest
  public void afterTest() {
	  //gathers all details from all tests and puts it under extent report
	  extent.flush();
  }

}

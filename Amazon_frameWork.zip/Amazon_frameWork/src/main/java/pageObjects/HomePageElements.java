package pageObjects;

public interface HomePageElements {
	
	
	String searchBox="//*[@id='twotabsearchtextbox']";
	String firstProdDisplayed="//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/span/div/div/div/div[2]/div/div/div[1]/h2/a/span";
	String searchButton="//*[contains(@id,'search-submit-button')]";
}

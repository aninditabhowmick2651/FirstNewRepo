import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GETRequest {

	//https://reqres.in/api/users/2
	//query parameter: https://reqres.in/api/users?page=2
//	https://jsonplaceholder.typicode.com/
//		 https://reqres.in/
//		 https://petstore.swagger.io/
//		 https://my-json-server.typicode.com/
//		 https://mockbin.org/
	@Test
	public void callGET()
	{
		Response rest=RestAssured.get("https://reqres.in/api/users/2");
		System.out.println("Response body: "+rest.asString());
		System.out.println("Status code: "+rest.getStatusCode());
	}
}

package BDD_approach;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class validateResponseHeader {
	@Test
	public void responseHeadre()
	{
	RequestSpecification reqsp=RestAssured.given();

	reqsp.baseUri("https://reqres.in");
	reqsp.basePath("/api/users/2");
	
	//create get request
	Response res=reqsp.get();
	String header=res.getHeader("Content-type");
	
	//print single header value
	System.out.println("Single value of header: "+header);
	
	Assert.assertEquals(header,"application/json; charset=utf-8","Content-type value is not matching");
	//print list of headers
	Headers headers=res.getHeaders();
	for(Header head:headers)
	{
		System.out.println("Key: "+head.getName()+" || Value: "+head.getValue());
	}
	}
	

}

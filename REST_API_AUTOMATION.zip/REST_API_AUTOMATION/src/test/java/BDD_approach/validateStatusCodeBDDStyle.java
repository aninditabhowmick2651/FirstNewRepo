package BDD_approach;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class validateStatusCodeBDDStyle {
	@Test	
	public void validateStatusLine()
	{
		Response res=given().when().get("https://reqres.in/api/users/2");
		String statusline=res.getStatusLine();
		System.out.println("�ctual statusLine:" +statusline);
		
		given().when().get("https://reqres.in/api/users/2").then().statusLine(statusline);
	}
 
	
}

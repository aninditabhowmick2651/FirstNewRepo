package BDD_approach;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class queryParam {
	@Test
	public void getUserData()
	{
		RequestSpecification reqSpec=RestAssured.given();
		reqSpec.baseUri("https://reqres.in");
		reqSpec.basePath("/api/users");
		//get user data from page 2 whose id is 8
		reqSpec.queryParam("page", 2).queryParam("id", 8);
		Response res=reqSpec.get();
		String str=res.getBody().asString();
		//String str=reqSpec.get().asString();
		System.out.println("User data of id 8: "+str);
		
		//validate user's first name
		JsonPath jpath=res.jsonPath();
		String fname=jpath.get("data.first_name");
		Assert.assertEquals(fname, "Lindsay");
		
		
	}

}

package BDD_approach;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Ignore;
//import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CRUD_response {
	@Ignore
	@Test
	public void get()
	{
	Response res=RestAssured.get("https://reqres.in/api/users?page=2");
	System.out.println("Response body: "+res.getBody().asString());
	System.out.println("status code: "+res.getStatusCode());
	//System.out.println("Time: "+res.getTime());
	System.out.println("Date: "+res.getHeader("Date"));
	
	//Validating status
	int status=res.getStatusCode();
	Assert.assertEquals(status, 200);
	
	}
	@Ignore
	@Test
	public void get2()
	{
		RestAssured.baseURI="https://reqres.in/api/users";
		RestAssured.given().queryParam("page", "2").when().get().getStatusCode();
	}
	
	@Test
	public void post()
	{
		RestAssured.baseURI="https://reqres.in/api/users";
		JSONObject jdata=new JSONObject();
		jdata.put("name", "AB1");
		jdata.put("job", "QA4");
		/*RestAssured.given().header("Content.Type","application/json").contentType(ContentType.JSON)
		.body(jdata.toJSONString()).when().post().then().statusCode(201).log().all();*/
		
		//validating body
		Response res=RestAssured.given().header("Content.Type","application/json").contentType(ContentType.JSON)
				.body(jdata.toJSONString()).when().post();
		String body=res.getBody().asString();
		System.out.println("deatils: "+body);
		JsonPath jpath=res.jsonPath();
		String id=jpath.getString("id");
		String name=jpath.getString("name");
		System.out.println("user id: "+id);
		Assert.assertEquals(name, "AB1","Check the name");
		
		
	}
	@Ignore
	@Test
	public void put()
	{
//		"name": "AB1",
//	    "job": "QA",
//	    "id": "328",
		//https://reqres.in/api/users/328
		RestAssured.baseURI="https://reqres.in/api/users/328";
		JSONObject jdata=new JSONObject();
		jdata.put("name", "AB2");
		jdata.put("job", "Police");
		RestAssured.given().header("Content.Type","application/json").contentType(ContentType.JSON)
		.body(jdata.toJSONString()).when().put().then().statusCode(200).log().all();
		
		
		
	}
	
	@Test(enabled=false)
	public void patch()
	{
//		"name": "AB1",
//	    "job": "QA",
//	    "id": "328",
		//https://reqres.in/api/users/328
		RestAssured.baseURI="https://reqres.in/api/users/328";
		JSONObject jdata=new JSONObject();
		jdata.put("name", "AB3");
		
		RestAssured.given().header("Content.Type","application/json").contentType(ContentType.JSON)
		.body(jdata.toJSONString()).when().patch().then().statusCode(200).log().all();
		
		
		
	}
	@Ignore
	@Test
	public void delete()
	{
		RestAssured.baseURI="https://reqres.in/api/users/328";
		RestAssured.given().when().delete().then().statusCode(204).log().all();
	}
}

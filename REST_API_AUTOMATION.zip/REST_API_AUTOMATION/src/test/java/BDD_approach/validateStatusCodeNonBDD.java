package BDD_approach;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class validateStatusCodeNonBDD {
  @Test
  public void getSingleUser() {
	  RestAssured.baseURI="https://reqres.in/api/users/2";
	  RequestSpecification reqspec=RestAssured.given();
	  Response res=reqspec.get();
	  int statuscode=res.getStatusCode();
	  Assert.assertEquals(statuscode,200,"status code is not as expected");
	  String statusline=res.getStatusLine();
	  System.out.println("StatusLine: "+statusline);
	  Assert.assertEquals(statusline,"HTTP/1.1 200 OK","Incorrect statusline received");
  }
  
  @Test
  public void getSingleUser1() {
	  RestAssured.baseURI="https://reqres.in/api/users/2";
	  RequestSpecification reqspec=RestAssured.given();
	  Response res=reqspec.get();
	  ValidatableResponse vres=res.then();
	  vres.statusCode(200);
	  vres.statusLine("HTTP/1.1 200 OK");
	  
  }
  
}

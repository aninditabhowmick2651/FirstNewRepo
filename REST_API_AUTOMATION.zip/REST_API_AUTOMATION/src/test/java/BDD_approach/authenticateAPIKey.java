package BDD_approach;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class authenticateAPIKey {
	
	@Test
	public void sendingAPIKey()
	{
		//50d04ad6295754b32ced6dca54a5d9b1
		//https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
		RequestSpecification rspec=RestAssured.given();
		rspec.baseUri("https://api.openweathermap.org");
		rspec.basePath("/data/2.5/weather?");
		rspec.queryParam("q", "Kolkata").queryParams("appid", "50d04ad6295754b32ced6dca54a5d9b1");
		Response rp=rspec.get();
		String str=rp.getBody().asString();
		System.out.println("Request body: "+str);
		String str1=rp.getStatusLine();
		System.out.println("Status line: "+str1);
	}

}

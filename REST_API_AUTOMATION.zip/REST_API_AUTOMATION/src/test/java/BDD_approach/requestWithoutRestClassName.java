package BDD_approach;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

/*making import static and adding * , so that we can directly use class variables 
and methods without using classname (Restassured)*/
import static io.restassured.RestAssured.*;

public class requestWithoutRestClassName {
  @Test
  public void get1() {
	  Response res=get("https://reqres.in/api/users?page=2");
		System.out.println("Response body: "+res.getBody().asString());
		System.out.println("status code: "+res.getStatusCode());
		//System.out.println("Time: "+res.getTime());
		System.out.println("Date: "+res.getHeader("Date"));
		
		//Validating status
		int status=res.getStatusCode();
		Assert.assertEquals(status, 200);
  }
  public void get2()
  {
	  baseURI="https://reqres.in/api/users";
		given().queryParam("page", "2").when().get().getStatusCode();
  }
}

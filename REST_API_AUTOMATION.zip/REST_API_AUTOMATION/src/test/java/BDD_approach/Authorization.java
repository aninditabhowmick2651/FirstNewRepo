package BDD_approach;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Authorization {
	@Ignore
	@Test
	public void basicAuth()
	{
		/*basic authorization uses BASE 64 encoding to encode username and password
		 * base auth has 2 type- preemptive,non-preemptive(default)
		 * non-preemtive- based on 2 requests- 1. first server asks for userid and password
		 									   2.	then we send the endpoint with these details
		 *preemtive- we send the authentication details with url by using preemptive keyword,
		 server may use or may nt use the userid and password
		*/
		//https://postman-echo.com/basic-auth
		RequestSpecification reqsp=RestAssured.given();
		reqsp.baseUri("https://postman-echo.com");
		reqsp.basePath("/basic-auth");
		//preemptive
		Response res=reqsp.auth().preemptive().basic("postman", "password").get();
		String str=res.getStatusLine();
		System.out.println("Status line: "+str);
		System.out.println("response body1: "+res.body().asString());
		System.out.println("response body2: "+res.getBody().asString());
	}
	@Ignore
	@Test
	public void digestAuth()
	{
		/*digest authentocation used different algorithms (ex. MD5) to encrypt uid and password
		*/
		//https://postman-echo.com/basic-auth
		RequestSpecification reqsp=RestAssured.given();
		reqsp.baseUri("https://httpbin.org");
		reqsp.basePath("/digest-auth/undefined/ani/ani");
		//preemptive
		Response res=reqsp.auth().digest("ani", "ani").get();
		String str=res.getStatusLine();
		System.out.println("Status line: "+str);
		System.out.println("response body1: "+res.body().asString());
		System.out.println("response body2: "+res.getBody().asString());
	}
	
@Test
	public void bearerToken()
	{
		//token-Bearer de6ae43a6e336b0eceb33bb14171fbaa1a764fee63700bf093c20dcbd15bea7d
		//https://gorest.co.in/public/v2/users
		
	    
		RequestSpecification rspec=RestAssured.given();
		rspec.baseUri("https://gorest.co.in");
		rspec.basePath("/public/v2/users");
		JSONObject jobj=new JSONObject();
		jobj.put("name", "ab34");
		jobj.put("email", "ab32@abc.com");
		jobj.put("gender", "male");
		jobj.put("status", "inactive");
		
		String token="Bearer de6ae43a6e336b0eceb33bb14171fbaa1a764fee63700bf093c20dcbd15bea7d";
		
		rspec.headers("Authorization",token).contentType(ContentType.JSON)
				.body(jobj.toJSONString());
		Response res=rspec.post();
	
		String str1=res.getBody().asString();
		int str2=res.getStatusCode();
		Assert.assertEquals(str2, 201);
		
		System.out.println("Status code: "+str2);
		System.out.println("response body1: "+str1);
		
	}

}
